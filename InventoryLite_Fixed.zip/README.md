# InventoryLite (Fixed Versions)

- AGP: 8.4.2
- Kotlin: 1.9.24
- Gradle Wrapper: 8.6
- Min SDK 24, Target 34

## Build
1. Mở bằng Android Studio. Khi thấy Upgrade Assistant, **không nâng cấp**.
2. File → Settings → Gradle → **Gradle JDK = Embedded JDK 17**.
3. Sync. Nếu Android Studio báo thiếu `gradle-wrapper.jar`, chọn **Generate/Download Gradle Wrapper** hoặc chạy:
   - Windows: `gradlew.bat wrapper --gradle-version 8.6`
   - macOS/Linux: `./gradlew wrapper --gradle-version 8.6`
4. Run ▶ để chạy. Hoặc Build → Build APK(s).
