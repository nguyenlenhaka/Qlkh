package com.example.inventory.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.AppDatabase
import com.example.inventory.data.Item
import com.example.inventory.data.ItemRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class InventoryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ItemRepository(AppDatabase.get(app).itemDao())

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    val items = _query.flatMapLatest { q ->
        if (q.isBlank()) repo.all() else repo.search(q)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(q: String) { _query.value = q }

    fun add(name: String, sku: String?, qty: Int, minQty: Int) = viewModelScope.launch {
        repo.insert(Item(name = name.trim(), sku = sku?.trim().takeUnless { it.isNullOrBlank() }, quantity = qty, minQuantity = minQty))
    }

    fun update(item: Item) = viewModelScope.launch { repo.update(item) }
    fun delete(item: Item) = viewModelScope.launch { repo.delete(item) }
    fun inc(id: Int) = viewModelScope.launch { repo.adjust(id, +1) }
    fun dec(id: Int) = viewModelScope.launch { repo.adjust(id, -1) }

    fun exportCsv(context: Context) {
        viewModelScope.launch {
            val snapshot = items.value
            val header = "id,name,sku,quantity,minQuantity\n"
            val rows = snapshot.joinToString("\n") {
                listOf(it.id, it.name.replace(",", " "), it.sku ?: "", it.quantity, it.minQuantity).joinToString(",")
            }
            val csv = header + rows
            val file = File(context.cacheDir, "inventory_export.csv")
            file.writeText(csv)
            val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Chia sẻ CSV"))
        }
    }
}
