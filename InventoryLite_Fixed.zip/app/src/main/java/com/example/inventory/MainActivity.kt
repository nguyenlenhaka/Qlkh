package com.example.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.inventory.data.Item
import com.example.inventory.ui.InventoryViewModel
import com.example.inventory.ui.theme.InventoryTheme

class MainActivity : ComponentActivity() {
    private val vm: InventoryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InventoryTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    InventoryScreen(vm = vm)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(vm: InventoryViewModel) {
    val items by vm.items.collectAsState()
    val query by vm.query.collectAsState()
    val ctx = LocalContext.current

    var showEditor by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Quản lý kho") },
                actions = {
                    IconButton(onClick = { vm.exportCsv(ctx) }) {
                        Icon(Icons.Default.Download, contentDescription = "Xuất CSV")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = "Thêm")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = query,
                onValueChange = vm::setQuery,
                label = { Text("Tìm theo tên hoặc SKU") },
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Danh sách trống. Nhấn + để thêm.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items, key = { it.id }) { item ->
                        ItemRow(
                            item = item,
                            onInc = { vm.inc(item.id) },
                            onDec = { vm.dec(item.id) },
                            onDelete = { vm.delete(item) }
                        )
                    }
                }
            }
        }
    }

    if (showEditor) {
        AddItemDialog(
            onDismiss = { showEditor = false },
            onSave = { name, sku, qty, minQty ->
                vm.add(name, sku, qty, minQty)
                showEditor = false
            }
        )
    }
}

@Composable
fun ItemRow(item: Item, onInc: () -> Unit, onDec: () -> Unit, onDelete: () -> Unit) {
    val low = item.minQuantity > 0 && item.quantity < item.minQuantity
    Card {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.titleMedium)
                val sub = buildString {
                    if (!item.sku.isNullOrBlank()) append("SKU: ${item.sku}   ")
                    append("Tồn: ${item.quantity}")
                    if (item.minQuantity > 0) append("  |  Mức tối thiểu: ${item.minQuantity}")
                }
                Text(sub, style = MaterialTheme.typography.bodySmall, color = if (low) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onDec, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("-") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = onInc, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("+") }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Xoá") }
            }
        }
    }
}

@Composable
fun AddItemDialog(onDismiss: () -> Unit, onSave: (String, String?, Int, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("0") }
    var minQty by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Thêm hàng hoá") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Tên") })
                OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU (tuỳ chọn)") })
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Số lượng ban đầu") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = minQty,
                    onValueChange = { minQty = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Mức tồn tối thiểu") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave(name, sku.ifBlank { null }, qty.toIntOrNull() ?: 0, minQty.toIntOrNull() ?: 0)
            }) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Huỷ") } }
    )
}
