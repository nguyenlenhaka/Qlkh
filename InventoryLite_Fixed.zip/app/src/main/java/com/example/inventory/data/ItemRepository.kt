package com.example.inventory.data

class ItemRepository(private val dao: ItemDao) {
    fun all() = dao.getAll()
    fun search(q: String) = dao.search(q)
    suspend fun insert(item: Item) = dao.insert(item)
    suspend fun update(item: Item) = dao.update(item)
    suspend fun delete(item: Item) = dao.delete(item)
    suspend fun adjust(id: Int, delta: Int) = dao.adjustQuantity(id, delta)
}
